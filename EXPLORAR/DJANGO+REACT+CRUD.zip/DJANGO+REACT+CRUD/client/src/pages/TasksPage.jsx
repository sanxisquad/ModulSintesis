import { TasksList } from "../components/TasksList";
export function TasksPage() {
    return (
<TasksList />
    );
    }   
